GLRRM - unofficial folder directory and preliminary proposed directory structure

NOTE: Zoe Miller zoe.a.miller@usace.army.miller
Date 12/19/18

Superior - dummy wrapper script
Middle Lakes - not final midlakes program - to add logging/handling, output writing, notes editing, etc
Ontario - nothing

To Add: script like "create_vault" for creating the 3 configuration files for each module from a master GLRRM config file...

And ... lots of other things down the road




